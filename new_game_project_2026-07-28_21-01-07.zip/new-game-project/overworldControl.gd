extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_released("k_Enter"):
		print("need to activate menu! called from top node")
	pass
	
	

	
func loadNewLevel(newLevel: String) -> void:
	#this is the code to laod new levels!
	var holder = get_node("%AreaHolder")
	holder.get_child(0).queue_free()
	var scene = load("res://" + newLevel)
	var sc = scene.instantiate()
	holder.add_child(sc)
	
